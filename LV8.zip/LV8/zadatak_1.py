import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
from PIL import Image

# Model / data parameters
num_classes = 10
input_shape = (28, 28, 1)

# Učitavanje podataka
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Prikaz karakteristika podataka
print('Train: X=%s, y=%s' % (x_train.shape, y_train.shape))
print('Test: X=%s, y=%s' % (x_test.shape, y_test.shape))

# Prikaz prvih 9 slika iz trening skupa
plt.figure(figsize=(10,10))
for i in range(9):
    plt.subplot(3,3,i+1)
    plt.imshow(x_train[i], cmap='gray')
    plt.title(f"Label: {y_train[i]}")
    plt.axis('off')
plt.show()

# Skaliranje i obrada podataka
x_train_s = x_train.astype("float32") / 255
x_test_s = x_test.astype("float32") / 255
x_train_s = np.expand_dims(x_train_s, -1)
x_test_s = np.expand_dims(x_test_s, -1)

print("x_train shape:", x_train_s.shape)
print(x_train_s.shape[0], "train samples")
print(x_test_s.shape[0], "test samples")

# Pretvorba labela u kategorijski format
y_train_s = keras.utils.to_categorical(y_train, num_classes)
y_test_s = keras.utils.to_categorical(y_test, num_classes)

# Kreiranje modela
model = keras.Sequential([
    keras.Input(shape=input_shape),
    layers.Flatten(),
    layers.Dense(512, activation='relu'),
    layers.Dense(256, activation='relu'),
    layers.Dense(num_classes, activation='softmax')
])
model.summary()

# Kompilacija modela
model.compile(
    loss='categorical_crossentropy',
    optimizer='adam',
    metrics=['accuracy']
)

# Treniranje modela
history = model.fit(
    x_train_s, 
    y_train_s,
    batch_size=128,
    epochs=10,
    validation_split=0.2
)

# Evaluacija modela
test_loss, test_acc = model.evaluate(x_test_s, y_test_s)
print(f'Test točnost: {test_acc:.4f}')

# Matrica zabune
y_pred = model.predict(x_test_s)
y_pred_classes = np.argmax(y_pred, axis=1)
conf_matrix = confusion_matrix(y_test, y_pred_classes)
print("Matrica zabune:")
print(conf_matrix)

# Spremanje modela
model.save('mnist_model.keras')
print("Model spremljen kao mnist_model.keras")



# Pronađi indekse pogrešnih predikcija - 8.4.2
y_pred_labels = np.argmax(y_pred, axis=1)
wrong_indices = np.where(y_pred_labels != y_test)[0]

# Prikaži prvih 9 pogrešnih slika
plt.figure(figsize=(10,10))
for i, idx in enumerate(wrong_indices[:9]):
    plt.subplot(3,3,i+1)
    plt.imshow(x_test[idx], cmap='gray')
    plt.title(f"Stvarno: {y_test[idx]}\nPredviđeno: {y_pred_labels[idx]}")
    plt.axis('off')
plt.show()



# Učitaj i prilagodi sliku - 8.4.3
model = keras.models.load_model("model_mnist.h5")
img_path = "test.png"
img = Image.open(img_path).convert("L")
plt.imshow(img, cmap="gray")
plt.title("Originalna slika")
plt.axis("off")
plt.show()

img_resized = img.resize((28, 28))
img_resized = np.array(img_resized).reshape((1, 28, 28, 1))
img_array = np.array(img_resized).astype("float32") / 255.0
img_array = img_array.reshape((28*28))

prediction = model.predict(np.array(img_resized))
predicted_class = np.argmax(prediction)
