import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, precision_score, recall_score, confusion_matrix


X, y = make_classification(n_samples=200, n_features=2, n_redundant=0, n_informative=2,
                            random_state=213, n_clusters_per_class=1, class_sep=1)

# train test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=5)

# ----- A -----

plt.figure()
plt.scatter(X_train[:,0], X_train[:,1], c=y_train, cmap='bwr', label='Trening')
plt.scatter(X_test[:,0], X_test[:,1], c=y_test, cmap='bwr', marker='x', label='Test')
plt.xlabel('x1')
plt.ylabel('x2')
plt.legend()
plt.show()

# ----- B -----

logisticRegression = LogisticRegression()
logisticRegression.fit(X_train, y_train)

# ----- C -----


θ1, θ2 = logisticRegression.coef_[0]  
θ0 = logisticRegression.intercept_[0] 

plt.scatter(
    X_train[:, 0], 
    X_train[:, 1],
    c=y_train,
    cmap='bwr',
    marker='o', 
    label='Trening skup', 
    alpha=0.4
    )

plt.scatter(
    X_test[:, 0], 
    X_test[:, 1], 
    c=y_test,
    cmap='bwr', 
    marker='x', 
    label='Testni skup', 
    alpha=0.4
    )

x = np.linspace(X[:, 0].min(), X[:, 0].max(), 200)

plt.plot(
    x, 
    (- θ0 - θ1 * x) / θ2, 
    color='black', 
    label='Granica odluke'
    )

plt.xlabel('X1')
plt.ylabel('X2')
plt.legend()
plt.show()


# ----- D -----

y_pred = logisticRegression.predict(X_test)  

cm = confusion_matrix(y_test, y_pred)
ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=logisticRegression.classes_).plot(cmap='bwr')
plt.show()

# Metrike
print(f"Točnost: {accuracy_score(y_test, y_pred):.2f}")
print(f"Preciznost: {precision_score(y_test, y_pred):.2f}") 
print(f"Odziv: {recall_score(y_test, y_pred):.2f}")

# ----- E -----

correct = y_test == y_pred
incorrect = ~correct
plt.scatter(X_test[correct,0], X_test[correct,1], c='green', label='Točno', marker= 'o')
plt.scatter(X_test[~correct,0], X_test[~correct,1], c='black', label='Pogrešno', marker = 'x')
plt.xlabel('X1')
plt.ylabel('X2')
plt.legend()
plt.show()

