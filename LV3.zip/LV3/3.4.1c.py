import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Filtriranje prema zapremini motora
filtered_data = data[(data['Engine Size (L)'] >= 2.5) & (data['Engine Size (L)'] <= 3.5)]

# Broj vozila i prosječna emisija CO2
print(f"Broj vozila: {len(filtered_data)}")
print(f"Prosječna emisija CO2: {filtered_data['CO2 Emissions (g/km)'].mean()}")
