
import matplotlib.pyplot as plt

# Učitavanje podataka
import pandas as pd
data = pd.read_csv('data_C02_emission.csv')

# Dijagram raspršenja
plt.scatter(data['Fuel Consumption City (L/100km)'], data['CO2 Emissions (g/km)'], c='green', alpha=0.5)
plt.title('Gradska potrošnja vs Emisija CO2')
plt.xlabel('Fuel Consumption City (L/100km)')
plt.ylabel('CO2 Emissions (g/km)')
plt.grid(True)
plt.show()
