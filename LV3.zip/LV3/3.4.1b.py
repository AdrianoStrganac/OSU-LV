import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

sorted_data = data.sort_values( by = 'Fuel Consumption City (L/100km)', ascending=False)

print("Tri automobila s najvecom gradskom potrosnjom:\n", sorted_data[['Make', 'Model', 'Fuel Consumption City (L/100km)']].head(3))

print("Tri automobila s najmanja gradskom potrosnjom:\n", sorted_data[['Make', 'Model', 'Fuel Consumption City (L/100km)']].tail(3))
