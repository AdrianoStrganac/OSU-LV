import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Filtriranje vozila na disel vozila 
filtered_cylinders = data[data['Fuel Type'].isin(["X", "D"])]

# Prikaz prosjecne potrosnje dizel i benzin vozila u gradskoj voznji
average_consumption = filtered_cylinders.groupby('Fuel Type')['Fuel Consumption City (L/100km)'].mean()
print("Prosječna potrošnja za dizel i benzin:")
print(average_consumption)