# Učitavanje podataka
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('data_C02_emission.csv')

# Grupiranje podataka prema tipu goriva
fuel_types = data['Fuel Type'].unique()
fuel_data = [data[data['Fuel Type'] == fuel]['Fuel Consumption Hwy (L/100km)'] for fuel in fuel_types]

# Kutijasti dijagram
plt.boxplot(fuel_data, labels=fuel_types, patch_artist=True)
plt.title('Izvangradska potrošnja prema tipu goriva')
plt.xlabel('Fuel Type')
plt.ylabel('Highway Consumption (L/100km)')
plt.grid(True)
plt.show()
