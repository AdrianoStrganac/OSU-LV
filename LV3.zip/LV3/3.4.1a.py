import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Informacije o DataFrame-u
print(data.info())

# Provjera nedostajućih vrijednosti
print("Nedostajuće vrijednosti po stupcima:")
print(data.isnull().sum())

# Provjera dupliciranih redaka
print(f"Broj dupliciranih redaka: {data.duplicated().sum()}")

# Brisanje dupliciranih i praznih redaka ako postoje
data = data.drop_duplicates()   
data.dropna()

# Konverzija kategorijskih stupaca u tip 'category'
categorical_columns = data.select_dtypes(include=['object']).columns
for col in categorical_columns:
    data[col] = data[col].astype('category')
