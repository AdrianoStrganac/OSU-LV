import pandas as pd

# Učitavanje podataka iz CSV datoteke
data = pd.read_csv('data_C02_emission.csv')

correlation_matrix = data.corr()
print("Korelacija između numeričkih veličina:")
print(correlation_matrix)
