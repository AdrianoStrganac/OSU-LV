import pandas as pd

# Učitavanje podataka iz CSV datoteke
data = pd.read_csv('data_C02_emission.csv')

# Filtriranje vozila s ručnim tipom mjenjača (Transmission počinje s 'M')
manual_transmission_vehicles = data[data['Transmission'].str.startswith('M')]

# Broj vozila s ručnim mjenjačem
num_manual_transmission = len(manual_transmission_vehicles)

print(f"Broj vozila s ručnim tipom mjenjača: {num_manual_transmission}")
