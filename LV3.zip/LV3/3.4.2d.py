# Učitavanje podataka
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('data_C02_emission.csv')


# Brojanje vozila po tipu goriva
fuel_counts = data['Fuel Type'].value_counts()

# Stupčasti dijagram
fuel_counts.plot(kind='bar', color='orange', edgecolor='black')
plt.title('Broj vozila po tipu goriva')
plt.xlabel('Fuel Type')
plt.ylabel('Count')
plt.grid(axis='y')
plt.show()
