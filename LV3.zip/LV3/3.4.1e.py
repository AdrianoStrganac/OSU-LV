import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Filtriranje liste na samo aute s 4,6,8 cilindra
filtered_cylinders = data[data['Cylinders'].isin([4, 6, 8])]

# Prosječna emisija CO2 prema broju cilindara
average_emissions = filtered_cylinders.groupby('Cylinders')['CO2 Emissions (g/km)'].mean()
print("Prosječna emisija CO2 prema broju cilindara:")
print(average_emissions)
