import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Filtiranje svih vozila marke audi
filtered_data = data[(data['Make'] == "Audi")]

# Ispis broja audi vozila
print(f"Broj audi vozila: {len(filtered_data)}")

# Filtriranje vozila na vozila s 4 cilindra
four_cylinders = filtered_data[filtered_data["Cylinders"] == 4]

# Ispis prosjecne sveuk potrosnje audi vozila 
print(f"Prosjecna emisija C02 za Audi: {four_cylinders['CO2 Emissions (g/km)'].mean().round(4)}")
