import pandas as pd

# Učitavanje podataka
data = pd.read_csv("data_C02_emission.csv")

# Filtriranje vozila na samo disel vozila
diesel_data = data[data['Fuel Type'] == 'D']

# Ispis disel vozila s najvecom gradskom potrosnjom
max_diesel_vehicle = diesel_data.loc[diesel_data['Fuel Consumption City (L/100km)'].idxmax()]
print("Vozilo s najvećom gradskom potrošnjom koje koristi dizelski motor:")
print(max_diesel_vehicle[['Make', 'Model', 'Fuel Consumption City (L/100km)']])
