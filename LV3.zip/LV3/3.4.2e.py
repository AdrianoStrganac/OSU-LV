# Učitavanje podataka
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('data_C02_emission.csv')

# Grupiranje podataka prema broju cilindara i izračun prosječne emisije CO2
avg_co2_by_cylinders = data.groupby('Cylinders')['CO2 Emissions (g/km)'].mean()

# Stupčasti dijagram
avg_co2_by_cylinders.plot(kind='bar', color='purple', edgecolor='black')
plt.title('Prosječna emisija CO2 prema broju cilindara')
plt.xlabel('Cylinders')
plt.ylabel('Average CO2 Emissions (g/km)')
plt.grid(axis='y')
plt.show()
