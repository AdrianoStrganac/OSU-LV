import matplotlib.pyplot as plt

# Učitavanje podataka
import pandas as pd
data = pd.read_csv('data_C02_emission.csv')

# Histogram emisije CO2
plt.hist(data['CO2 Emissions (g/km)'], bins=20, color='blue', edgecolor='black')
plt.title('Histogram emisije CO2')
plt.xlabel('CO2 Emissions (g/km)')
plt.ylabel('Frequency')
plt.show()
