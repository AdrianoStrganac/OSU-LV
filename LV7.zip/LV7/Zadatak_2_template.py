import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as Image
from sklearn.cluster import KMeans

# ucitaj sliku
img = Image.imread("imgs\\test_3.jpg")

# prikazi originalnu sliku
plt.figure()
plt.title("Originalna slika")
plt.imshow(img)
plt.tight_layout()
plt.show()

# pretvori vrijednosti elemenata slike u raspon 0 do 1
img = img.astype(np.float64) / 255

# transfromiraj sliku u 2D numpy polje (jedan red su RGB komponente elementa slike)
w,h,d = img.shape
img_array = np.reshape(img, (w*h, d))

# rezultatna slika
img_array_aprox = img_array.copy()

# 7.5.2 1
# Broj različitih boja u slici
unique_colors = np.unique(img_array, axis=0)
print(f"Broj različitih boja u slici: {len(unique_colors)}")

# 7.5.2 2
# Primjena K srednjih vrijednosti
K = 3  # Promijenite broj grupa za eksperimentiranje
kmeans = KMeans(n_clusters=K, random_state=0)
kmeans.fit(img_array)
labels = kmeans.predict(img_array)


# 7.5.2 3
# Zamjena vrijednosti s pripadajućim centrom
centers = kmeans.cluster_centers_
img_array_aprox = centers[labels]
img_aprox = np.reshape(img_array_aprox, (w, h, d))

# Prikaz rezultantne slike
plt.figure()
plt.title(f"Kvantizirana slika (K={K})")
plt.imshow(img_aprox)
plt.tight_layout()
plt.show()


# 7.5.2 6
# Grafički prikaz ovisnosti J o broju grupa K
inertias = []
K_values = range(1, 11)
for K in K_values:
    kmeans = KMeans(n_clusters=K, random_state=0)
    kmeans.fit(img_array)
    inertias.append(kmeans.inertia_)

plt.figure()
plt.plot(K_values, inertias, marker='o')
plt.title("Ovisnost J o broju grupa K")
plt.xlabel("Broj grupa K")
plt.ylabel("Inercija (J)")
plt.show()

# 7.5.2 7 
# Prikaz elemenata slike koji pripadaju jednoj grupi
for i in range(K):
    binary_img = (labels == i).astype(np.float64)
    binary_img = np.reshape(binary_img, (w, h))
    plt.figure()
    plt.title(f"Grupa {i+1}")
    plt.imshow(binary_img, cmap='gray')
    plt.tight_layout()
    plt.show()



